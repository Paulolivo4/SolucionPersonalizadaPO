﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SolutionPO.Models;

namespace SolutionPO.Controllers
{
    public class PORegistroController : Controller
    {
        private readonly SolutionPOContext _context;

        public PORegistroController(SolutionPOContext context)
        {
            _context = context;
        }

        // GET: PORegistro
        public async Task<IActionResult> Index()
        {
            return View(await _context.PORegistro.ToListAsync());
        }

        // GET: PORegistro/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pORegistro = await _context.PORegistro
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pORegistro == null)
            {
                return NotFound();
            }

            return View(pORegistro);
        }

        // GET: PORegistro/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PORegistro/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nombre,CorreoElectronico,NumeroTelefono")] PORegistro pORegistro)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pORegistro);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(pORegistro);
        }

        // GET: PORegistro/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pORegistro = await _context.PORegistro.FindAsync(id);
            if (pORegistro == null)
            {
                return NotFound();
            }
            return View(pORegistro);
        }

        // POST: PORegistro/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nombre,CorreoElectronico,NumeroTelefono")] PORegistro pORegistro)
        {
            if (id != pORegistro.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pORegistro);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PORegistroExists(pORegistro.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(pORegistro);
        }

        // GET: PORegistro/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pORegistro = await _context.PORegistro
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pORegistro == null)
            {
                return NotFound();
            }

            return View(pORegistro);
        }

        // POST: PORegistro/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pORegistro = await _context.PORegistro.FindAsync(id);
            if (pORegistro != null)
            {
                _context.PORegistro.Remove(pORegistro);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PORegistroExists(int id)
        {
            return _context.PORegistro.Any(e => e.Id == id);
        }
    }
}
