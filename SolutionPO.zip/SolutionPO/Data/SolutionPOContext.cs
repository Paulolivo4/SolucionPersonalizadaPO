﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SolutionPO.Models;

    public class SolutionPOContext : DbContext
    {
        public SolutionPOContext (DbContextOptions<SolutionPOContext> options)
            : base(options)
        {
        }

        public DbSet<SolutionPO.Models.PORegistro> PORegistro { get; set; } = default!;
    }
